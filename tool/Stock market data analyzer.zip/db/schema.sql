CREATE TABLE IF NOT EXISTS symbols (
    ticker TEXT PRIMARY KEY,
    name TEXT,
    exchange TEXT,
    currency TEXT
);

CREATE TABLE IF NOT EXISTS candles_daily (
    ticker TEXT NOT NULL,
    date TEXT NOT NULL,
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    adj_close REAL,
    volume INTEGER,
    PRIMARY KEY (ticker, date),
    FOREIGN KEY (ticker) REFERENCES symbols (ticker)
);

CREATE TABLE IF NOT EXISTS indicators_daily (
    ticker TEXT NOT NULL,
    date TEXT NOT NULL,
    sma20 REAL,
    sma50 REAL,
    rsi14 REAL,
    macd REAL,
    macd_signal REAL,
    macd_hist REAL,
    bb_upper REAL,
    bb_mid REAL,
    bb_lower REAL,
    PRIMARY KEY (ticker, date),
    FOREIGN KEY (ticker, date) REFERENCES candles_daily (ticker, date)
);

CREATE TABLE IF NOT EXISTS backtests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    params_json TEXT,
    start TEXT,
    end TEXT,
    ticker TEXT,
    pnl REAL,
    max_dd REAL,
    sharpe REAL,
    trades INTEGER,
    win_rate REAL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticker) REFERENCES symbols (ticker)
);

CREATE TABLE IF NOT EXISTS portfolio_tx (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    ts TEXT NOT NULL,
    side TEXT NOT NULL,
    qty REAL NOT NULL,
    price REAL NOT NULL,
    fees REAL DEFAULT 0,
    FOREIGN KEY (ticker) REFERENCES symbols (ticker)
);

CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticker TEXT NOT NULL,
    rule TEXT NOT NULL,
    threshold REAL,
    active INTEGER DEFAULT 1,
    last_fired TEXT,
    FOREIGN KEY (ticker) REFERENCES symbols (ticker)
);
