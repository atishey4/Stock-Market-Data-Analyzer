from pathlib import Path
import sqlite3


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "stock_market.db"
SCHEMA_PATH = BASE_DIR / "schema.sql"


def init_db(db_path: Path = DB_PATH) -> Path:
    schema = SCHEMA_PATH.read_text(encoding="utf-8")

    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.executescript(schema)

    return db_path


if __name__ == "__main__":
    initialized_path = init_db()
    print(f"Initialized database at {initialized_path}")
