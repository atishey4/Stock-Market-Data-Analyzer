from datetime import datetime, timezone
from pathlib import Path
import sqlite3

import pandas as pd


def _connect(db: str | Path | sqlite3.Connection) -> tuple[sqlite3.Connection, bool]:
    if isinstance(db, sqlite3.Connection):
        return db, False

    return sqlite3.connect(db), True


def _active_alerts(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql_query(
        """
        SELECT id, ticker, rule, threshold, last_fired
        FROM alerts
        WHERE active = 1
        ORDER BY ticker, id;
        """,
        conn,
    )


def _latest_rows(conn: sqlite3.Connection, ticker: str, limit: int = 2) -> pd.DataFrame:
    return pd.read_sql_query(
        """
        SELECT
            c.ticker,
            c.date,
            c.close,
            i.sma20,
            i.sma50,
            i.rsi14,
            i.bb_lower
        FROM candles_daily c
        JOIN indicators_daily i
            ON c.ticker = i.ticker
            AND c.date = i.date
        WHERE c.ticker = ?
        ORDER BY c.date DESC
        LIMIT ?;
        """,
        conn,
        params=(ticker, limit),
    ).sort_values("date")


def _is_cross_buy(rows: pd.DataFrame) -> bool:
    if len(rows) < 2:
        return False

    prev = rows.iloc[-2]
    curr = rows.iloc[-1]
    values = [prev.sma20, prev.sma50, curr.sma20, curr.sma50]
    if any(pd.isna(value) for value in values):
        return False

    return prev.sma20 <= prev.sma50 and curr.sma20 > curr.sma50


def _fires(alert: pd.Series, rows: pd.DataFrame) -> bool:
    if rows.empty:
        return False

    curr = rows.iloc[-1]
    rule = str(alert.rule).upper()
    threshold = alert.threshold

    if rule == "RSI_LT":
        return pd.notna(curr.rsi14) and pd.notna(threshold) and curr.rsi14 < threshold

    if rule == "CLOSE_LT_BBLOWER":
        return pd.notna(curr.close) and pd.notna(curr.bb_lower) and curr.close < curr.bb_lower

    if rule == "SMA_CROSS_BUY":
        return _is_cross_buy(rows)

    return False


def evaluate_once(db: str | Path | sqlite3.Connection) -> list[dict]:
    conn, should_close = _connect(db)
    fired = []

    try:
        alerts = _active_alerts(conn)
        fired_at = datetime.now(timezone.utc).isoformat()

        for alert in alerts.itertuples(index=False):
            rows = _latest_rows(conn, alert.ticker)
            alert_series = pd.Series(alert._asdict())

            if not _fires(alert_series, rows):
                continue

            latest = rows.iloc[-1]
            payload = {
                "id": int(alert.id),
                "ticker": alert.ticker,
                "rule": alert.rule,
                "threshold": alert.threshold,
                "date": latest.date,
                "fired_at": fired_at,
            }
            fired.append(payload)
            print(
                "ALERT "
                f"id={payload['id']} ticker={payload['ticker']} "
                f"rule={payload['rule']} threshold={payload['threshold']} "
                f"date={payload['date']}"
            )
            conn.execute(
                "UPDATE alerts SET last_fired = ? WHERE id = ?;",
                (fired_at, alert.id),
            )

        conn.commit()
    finally:
        if should_close:
            conn.close()

    return fired
