from pathlib import Path
import math
import sqlite3
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from src.backtest import run_sma_backtest, save_backtest
from src.ingest import upsert_daily
from src.portfolio import mark_to_market


BASE_DIR = Path(__file__).resolve().parents[1]
DB_PATH = BASE_DIR / "db" / "stock_market.db"

app = FastAPI(title="Stock Market Data Analyzer")


class SmaBacktestRequest(BaseModel):
    ticker: str
    fee_bps: float = 5
    start: str | None = None
    end: str | None = None
    save: bool = False


class AlertCreate(BaseModel):
    ticker: str
    rule: str
    threshold: float | None = None
    active: bool = True


def _connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def _clean(value: Any) -> Any:
    if value is None:
        return None

    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None

    if isinstance(value, dict):
        return {key: _clean(item) for key, item in value.items()}

    if isinstance(value, list):
        return [_clean(item) for item in value]

    return value


def _rows_to_dicts(rows: list[sqlite3.Row]) -> list[dict]:
    return [_clean(dict(row)) for row in rows]


@app.post("/refresh/{ticker}")
def refresh_ticker(
    ticker: str,
    start: str | None = Query(default=None),
    end: str | None = Query(default=None),
) -> dict:
    try:
        inserted_candles = upsert_daily(DB_PATH, ticker.upper(), start=start, end=end)

        from src.indicators import compute_indicators

        inserted_indicators = compute_indicators(DB_PATH, ticker.upper())
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {
        "ticker": ticker.upper(),
        "candles": inserted_candles,
        "indicators": inserted_indicators,
    }


@app.get("/chart/{ticker}")
def chart(ticker: str, days: int = Query(default=252, ge=1, le=5000)) -> dict:
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT *
            FROM (
                SELECT
                    c.ticker,
                    c.date,
                    c.open,
                    c.high,
                    c.low,
                    c.close,
                    c.adj_close,
                    c.volume,
                    i.sma20,
                    i.sma50,
                    i.rsi14,
                    i.macd,
                    i.macd_signal,
                    i.macd_hist,
                    i.bb_upper,
                    i.bb_mid,
                    i.bb_lower
                FROM candles_daily c
                LEFT JOIN indicators_daily i
                    ON c.ticker = i.ticker
                    AND c.date = i.date
                WHERE c.ticker = ?
                ORDER BY c.date DESC
                LIMIT ?
            )
            ORDER BY date ASC;
            """,
            (ticker.upper(), days),
        ).fetchall()

    return {"ticker": ticker.upper(), "days": days, "data": _rows_to_dicts(rows)}


@app.post("/backtest/sma")
def backtest_sma(request: SmaBacktestRequest) -> dict:
    try:
        results = run_sma_backtest(
            DB_PATH,
            request.ticker.upper(),
            fee_bps=request.fee_bps,
            start=request.start,
            end=request.end,
        )
        if request.save:
            results["backtest_id"] = save_backtest(DB_PATH, results)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return _clean(results)


@app.get("/portfolio")
def portfolio() -> dict:
    try:
        marked = mark_to_market(DB_PATH)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {"positions": _clean(marked.to_dict(orient="records"))}


@app.get("/alerts")
def list_alerts(active: bool = True) -> dict:
    with _connect() as conn:
        rows = conn.execute(
            """
            SELECT id, ticker, rule, threshold, active, last_fired
            FROM alerts
            WHERE (? = 0 OR active = 1)
            ORDER BY ticker, id;
            """,
            (1 if active else 0,),
        ).fetchall()

    return {"alerts": _rows_to_dicts(rows)}


@app.post("/alerts")
def create_alert(alert: AlertCreate) -> dict:
    with _connect() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO symbols (ticker) VALUES (?);",
            (alert.ticker.upper(),),
        )
        cursor = conn.execute(
            """
            INSERT INTO alerts (ticker, rule, threshold, active)
            VALUES (?, ?, ?, ?);
            """,
            (
                alert.ticker.upper(),
                alert.rule.upper(),
                alert.threshold,
                1 if alert.active else 0,
            ),
        )
        conn.commit()
        alert_id = int(cursor.lastrowid)
        row = conn.execute(
            """
            SELECT id, ticker, rule, threshold, active, last_fired
            FROM alerts
            WHERE id = ?;
            """,
            (alert_id,),
        ).fetchone()

    return {"alert": _clean(dict(row))}
