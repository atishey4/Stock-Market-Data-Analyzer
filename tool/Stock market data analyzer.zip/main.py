from datetime import date, timedelta
from pathlib import Path
import sqlite3

import pandas as pd

from db.init_db import init_db
from src.backtest import run_sma_backtest
from src.indicators import compute_indicators, simple_signal
from src.ingest import upsert_daily
from src.plots import bollinger_chart, daily_returns, price_with_ma, volatility_rolling
from src.report import generate_report


BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "db" / "stock_market.db"
WATCHLIST = ["RELIANCE.NS", "TCS.NS", "INFY.NS", "^NSEI"]


def load_analysis_frame(ticker: str) -> pd.DataFrame:
    query = """
        SELECT
            c.ticker,
            c.date,
            c.open,
            c.high,
            c.low,
            c.close,
            c.adj_close,
            c.volume,
            i.sma20,
            i.sma50,
            i.rsi14,
            i.macd,
            i.macd_signal,
            i.macd_hist,
            i.bb_upper,
            i.bb_mid,
            i.bb_lower
        FROM candles_daily c
        LEFT JOIN indicators_daily i
            ON c.ticker = i.ticker
            AND c.date = i.date
        WHERE c.ticker = ?
        ORDER BY c.date;
    """
    with sqlite3.connect(DB_PATH) as conn:
        return pd.read_sql_query(query, conn, params=(ticker,))


def latest_signal(frame: pd.DataFrame) -> str:
    indicator_rows = frame.dropna(subset=["sma20", "sma50"])
    if len(indicator_rows) < 2:
        return "HOLD"

    return simple_signal(indicator_rows.iloc[-2], indicator_rows.iloc[-1])


def run_pipeline() -> list[dict]:
    init_db(DB_PATH)
    start = (date.today() - timedelta(days=730)).isoformat()
    end = date.today().isoformat()
    summaries = []

    for ticker in WATCHLIST:
        print(f"Refreshing {ticker}...")
        try:
            upsert_daily(DB_PATH, ticker, start=start, end=end)
            compute_indicators(DB_PATH, ticker)
            backtest = run_sma_backtest(DB_PATH, ticker, start=start, end=end)
            frame = load_analysis_frame(ticker)

            if frame.empty:
                summaries.append({"ticker": ticker, "error": "no data"})
                continue

            price_with_ma(frame, ticker)
            daily_returns(frame, ticker)
            volatility_rolling(frame, ticker)
            bollinger_chart(frame, ticker)
            generate_report(ticker)

            latest = frame.iloc[-1]
            summaries.append(
                {
                    "ticker": ticker,
                    "latest_close": latest.close,
                    "signal": latest_signal(frame),
                    "rsi14": latest.rsi14,
                    "sharpe": backtest["sharpe"],
                    "pnl": backtest["pnl"],
                }
            )
        except Exception as exc:
            summaries.append({"ticker": ticker, "error": str(exc)})

    return summaries


def print_summary(summaries: list[dict]) -> None:
    print("\nPipeline Summary")
    print("-" * 88)
    print(
        f"{'Ticker':<14} {'Latest Close':>14} {'Signal':>10} "
        f"{'RSI14':>10} {'Sharpe':>10} {'PnL':>10}"
    )
    print("-" * 88)

    for summary in summaries:
        if "error" in summary:
            print(f"{summary['ticker']:<14} ERROR: {summary['error']}")
            continue

        print(
            f"{summary['ticker']:<14} "
            f"{summary['latest_close']:>14,.2f} "
            f"{summary['signal']:>10} "
            f"{summary['rsi14']:>10.2f} "
            f"{summary['sharpe']:>10.2f} "
            f"{summary['pnl']:>10.2%}"
        )


if __name__ == "__main__":
    print_summary(run_pipeline())
