from pathlib import Path
import sqlite3

import pandas as pd


BASE_DIR = Path(__file__).resolve().parents[1]
DB_PATH = BASE_DIR / "db" / "stock_market.db"
REPORTS_DIR = BASE_DIR / "reports"


def _signal(prev_row: pd.Series | None, curr_row: pd.Series) -> str:
    if prev_row is None:
        return "HOLD"

    values = [prev_row.sma20, prev_row.sma50, curr_row.sma20, curr_row.sma50]
    if any(pd.isna(value) for value in values):
        return "HOLD"

    if prev_row.sma20 <= prev_row.sma50 and curr_row.sma20 > curr_row.sma50:
        return "BUY"

    if prev_row.sma20 >= prev_row.sma50 and curr_row.sma20 < curr_row.sma50:
        return "SELL"

    return "HOLD"


def generate_report(ticker: str) -> Path:
    query = """
        SELECT
            c.date,
            c.close,
            i.sma20,
            i.sma50,
            i.rsi14
        FROM candles_daily c
        LEFT JOIN indicators_daily i
            ON c.ticker = i.ticker
            AND c.date = i.date
        WHERE c.ticker = ?
        ORDER BY c.date;
    """

    with sqlite3.connect(DB_PATH) as conn:
        frame = pd.read_sql_query(query, conn, params=(ticker.upper(),))

    frame["daily_return"] = frame["close"].pct_change()
    signals = []
    previous = None
    for row in frame.itertuples(index=False):
        current = pd.Series(row._asdict())
        signals.append(_signal(previous, current))
        previous = current

    frame["signal"] = signals
    report = frame[
        ["date", "close", "sma20", "sma50", "rsi14", "daily_return", "signal"]
    ]

    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    path = REPORTS_DIR / f"{ticker.upper()}_analysis.csv"
    report.to_csv(path, index=False)
    return path
