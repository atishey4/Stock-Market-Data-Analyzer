from pathlib import Path
import sqlite3

import pandas as pd
import yfinance as yf


DATA_DIR = Path(__file__).resolve().parents[1] / "data"
REQUIRED_COLUMNS = [
    "date",
    "open",
    "high",
    "low",
    "close",
    "adj_close",
    "volume",
]


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    normalized = df.copy()
    normalized.columns = [
        str(column).strip().lower().replace(" ", "_") for column in normalized.columns
    ]

    if "date" not in normalized.columns:
        normalized = normalized.reset_index()
        normalized.columns = [
            str(column).strip().lower().replace(" ", "_")
            for column in normalized.columns
        ]

    if "adj_close" not in normalized.columns:
        normalized["adj_close"] = normalized["close"]

    normalized["date"] = pd.to_datetime(normalized["date"]).dt.strftime("%Y-%m-%d")
    normalized = normalized[REQUIRED_COLUMNS]
    return normalized.dropna(subset=["date", "open", "high", "low", "close"])


def _read_fallback_csv(ticker: str) -> pd.DataFrame:
    fallback_path = DATA_DIR / f"{ticker}.csv"
    if not fallback_path.exists():
        raise FileNotFoundError(f"No fallback CSV found at {fallback_path}")

    return pd.read_csv(fallback_path)


def fetch_daily(ticker: str, start: str | None = None, end: str | None = None) -> pd.DataFrame:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    try:
        raw = yf.download(
            ticker,
            start=start,
            end=end,
            auto_adjust=False,
            progress=False,
        )
        if raw.empty:
            raise ValueError(f"No data returned by yfinance for {ticker}")

        raw_path = DATA_DIR / f"{ticker}_raw.csv"
        raw.to_csv(raw_path)
    except Exception:
        raw = _read_fallback_csv(ticker)

    return _normalize_columns(raw)


def _connect(db: str | Path | sqlite3.Connection) -> tuple[sqlite3.Connection, bool]:
    if isinstance(db, sqlite3.Connection):
        return db, False

    return sqlite3.connect(db), True


def upsert_daily(
    db: str | Path | sqlite3.Connection,
    ticker: str,
    start: str | None = None,
    end: str | None = None,
    data: pd.DataFrame | None = None,
) -> int:
    daily = _normalize_columns(data) if data is not None else fetch_daily(ticker, start, end)
    conn, should_close = _connect(db)

    rows = [
        (
            ticker,
            row.date,
            row.open,
            row.high,
            row.low,
            row.close,
            row.adj_close,
            int(row.volume) if pd.notna(row.volume) else None,
        )
        for row in daily.itertuples(index=False)
    ]

    try:
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("INSERT OR IGNORE INTO symbols (ticker) VALUES (?);", (ticker,))
        conn.executemany(
            """
            INSERT OR REPLACE INTO candles_daily (
                ticker, date, open, high, low, close, adj_close, volume
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """,
            rows,
        )
        conn.commit()
    finally:
        if should_close:
            conn.close()

    return len(rows)
