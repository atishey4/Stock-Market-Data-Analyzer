from pathlib import Path
import json
import sqlite3

import numpy as np
import pandas as pd


TRADING_DAYS = 252


def _connect(db: str | Path | sqlite3.Connection) -> tuple[sqlite3.Connection, bool]:
    if isinstance(db, sqlite3.Connection):
        return db, False

    return sqlite3.connect(db), True


def _load_backtest_data(
    conn: sqlite3.Connection,
    ticker: str,
    start: str | None = None,
    end: str | None = None,
) -> pd.DataFrame:
    where = ["c.ticker = ?"]
    params: list[str] = [ticker]

    if start is not None:
        where.append("c.date >= ?")
        params.append(start)

    if end is not None:
        where.append("c.date <= ?")
        params.append(end)

    query = f"""
        SELECT
            c.ticker,
            c.date,
            c.open,
            c.high,
            c.low,
            c.close,
            c.adj_close,
            c.volume,
            i.sma20,
            i.sma50
        FROM candles_daily c
        JOIN indicators_daily i
            ON c.ticker = i.ticker
            AND c.date = i.date
        WHERE {" AND ".join(where)}
        ORDER BY c.date;
    """
    return pd.read_sql_query(query, conn, params=params)


def _sharpe_ratio(returns: pd.Series) -> float:
    std = returns.std()
    if pd.isna(std) or std == 0:
        return 0.0

    return float(np.sqrt(TRADING_DAYS) * returns.mean() / std)


def _max_drawdown(equity: pd.Series) -> float:
    drawdown = equity / equity.cummax() - 1
    return float(drawdown.min()) if not drawdown.empty else 0.0


def _trade_returns(frame: pd.DataFrame) -> list[float]:
    trades = []
    in_trade = False
    trade_return = 1.0

    for row in frame.itertuples(index=False):
        if row.position == 1 and not in_trade:
            in_trade = True
            trade_return = 1.0

        if in_trade:
            trade_return *= 1 + row.net_return

        if in_trade and row.position == 0:
            trades.append(trade_return - 1)
            in_trade = False

    if in_trade:
        trades.append(trade_return - 1)

    return trades


def run_sma_backtest(
    db: str | Path | sqlite3.Connection,
    ticker: str,
    fee_bps: float = 5,
    start: str | None = None,
    end: str | None = None,
) -> dict:
    conn, should_close = _connect(db)

    try:
        frame = _load_backtest_data(conn, ticker, start, end)
    finally:
        if should_close:
            conn.close()

    if frame.empty:
        return {
            "name": "SMA20/SMA50 Crossover",
            "ticker": ticker,
            "start": start,
            "end": end,
            "fee_bps": fee_bps,
            "pnl": 0.0,
            "max_dd": 0.0,
            "sharpe": 0.0,
            "trades": 0,
            "win_rate": 0.0,
            "equity_curve": [],
        }

    frame = frame.dropna(subset=["sma20", "sma50"]).copy()
    if frame.empty:
        return {
            "name": "SMA20/SMA50 Crossover",
            "ticker": ticker,
            "start": start,
            "end": end,
            "fee_bps": fee_bps,
            "pnl": 0.0,
            "max_dd": 0.0,
            "sharpe": 0.0,
            "trades": 0,
            "win_rate": 0.0,
            "equity_curve": [],
        }

    price_col = "adj_close" if frame["adj_close"].notna().any() else "close"
    fee_rate = fee_bps / 10000

    frame["signal"] = (frame["sma20"] > frame["sma50"]).astype(int)
    frame["position"] = frame["signal"].shift(1).fillna(0).astype(int)
    frame["asset_return"] = frame[price_col].pct_change().fillna(0)
    frame["turnover"] = frame["position"].diff().abs().fillna(frame["position"])
    frame["cost"] = frame["turnover"] * fee_rate
    frame["gross_return"] = frame["position"] * frame["asset_return"]
    frame["net_return"] = frame["gross_return"] - frame["cost"]
    frame["equity"] = (1 + frame["net_return"]).cumprod()

    trade_returns = _trade_returns(frame)
    wins = sum(1 for trade_return in trade_returns if trade_return > 0)
    trades = len(trade_returns)

    actual_start = str(frame["date"].iloc[0])
    actual_end = str(frame["date"].iloc[-1])
    pnl = float(frame["equity"].iloc[-1] - 1)
    win_rate = float(wins / trades) if trades else 0.0

    equity_curve = [
        {
            "date": row.date,
            "equity": float(row.equity),
            "asset_return": float(row.asset_return),
            "net_return": float(row.net_return),
            "position": int(row.position),
        }
        for row in frame.itertuples(index=False)
    ]

    return {
        "name": "SMA20/SMA50 Crossover",
        "ticker": ticker,
        "start": actual_start,
        "end": actual_end,
        "fee_bps": fee_bps,
        "pnl": pnl,
        "max_dd": _max_drawdown(frame["equity"]),
        "sharpe": _sharpe_ratio(frame["net_return"]),
        "trades": trades,
        "win_rate": win_rate,
        "equity_curve": equity_curve,
    }


def save_backtest(
    db: str | Path | sqlite3.Connection,
    results: dict,
    name: str | None = None,
) -> int:
    conn, should_close = _connect(db)
    backtest_name = name or results.get("name", "SMA20/SMA50 Crossover")
    params = {
        "fee_bps": results.get("fee_bps"),
        "strategy": "sma20_sma50_crossover",
    }

    try:
        cursor = conn.execute(
            """
            INSERT INTO backtests (
                name, params_json, start, end, ticker, pnl, max_dd, sharpe,
                trades, win_rate
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """,
            (
                backtest_name,
                json.dumps(params),
                results.get("start"),
                results.get("end"),
                results.get("ticker"),
                results.get("pnl"),
                results.get("max_dd"),
                results.get("sharpe"),
                results.get("trades"),
                results.get("win_rate"),
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        if should_close:
            conn.close()
