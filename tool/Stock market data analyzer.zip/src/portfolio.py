from datetime import datetime, timezone
from pathlib import Path
import sqlite3

import pandas as pd


def _connect(db: str | Path | sqlite3.Connection) -> tuple[sqlite3.Connection, bool]:
    if isinstance(db, sqlite3.Connection):
        return db, False

    return sqlite3.connect(db), True


def add_transaction(
    db: str | Path | sqlite3.Connection,
    ticker: str,
    side: str,
    qty: float,
    price: float,
    fees: float = 0,
) -> int:
    side = side.upper()
    if side not in {"BUY", "SELL"}:
        raise ValueError("side must be BUY or SELL")

    if qty <= 0:
        raise ValueError("qty must be greater than 0")

    if price < 0:
        raise ValueError("price cannot be negative")

    conn, should_close = _connect(db)
    ts = datetime.now(timezone.utc).isoformat()

    try:
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("INSERT OR IGNORE INTO symbols (ticker) VALUES (?);", (ticker,))
        cursor = conn.execute(
            """
            INSERT INTO portfolio_tx (ticker, ts, side, qty, price, fees)
            VALUES (?, ?, ?, ?, ?, ?);
            """,
            (ticker, ts, side, qty, price, fees),
        )
        conn.commit()
        return int(cursor.lastrowid)
    finally:
        if should_close:
            conn.close()


def _transactions(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql_query(
        """
        SELECT ticker, ts, side, qty, price, fees
        FROM portfolio_tx
        ORDER BY ticker, ts, id;
        """,
        conn,
    )


def positions(db: str | Path | sqlite3.Connection) -> pd.DataFrame:
    conn, should_close = _connect(db)

    try:
        transactions = _transactions(conn)
    finally:
        if should_close:
            conn.close()

    if transactions.empty:
        return pd.DataFrame(
            columns=["ticker", "qty", "avg_cost", "cost_basis", "buys", "sells"]
        )

    records = []
    for ticker, group in transactions.groupby("ticker", sort=True):
        qty = 0.0
        cost_basis = 0.0
        buys = 0
        sells = 0

        for row in group.itertuples(index=False):
            tx_qty = float(row.qty)
            tx_value = tx_qty * float(row.price) + float(row.fees or 0)

            if row.side.upper() == "BUY":
                qty += tx_qty
                cost_basis += tx_value
                buys += 1
            elif row.side.upper() == "SELL":
                avg_cost = cost_basis / qty if qty else 0.0
                sell_qty = min(tx_qty, qty)
                qty -= tx_qty
                cost_basis -= avg_cost * sell_qty
                sells += 1

        if qty > 0:
            records.append(
                {
                    "ticker": ticker,
                    "qty": qty,
                    "avg_cost": cost_basis / qty,
                    "cost_basis": cost_basis,
                    "buys": buys,
                    "sells": sells,
                }
            )

    return pd.DataFrame.from_records(
        records,
        columns=["ticker", "qty", "avg_cost", "cost_basis", "buys", "sells"],
    )


def mark_to_market(db: str | Path | sqlite3.Connection) -> pd.DataFrame:
    current_positions = positions(db)
    if current_positions.empty:
        return current_positions.assign(
            latest_date=pd.Series(dtype="object"),
            latest_close=pd.Series(dtype="float64"),
            market_value=pd.Series(dtype="float64"),
            unrealized_pnl=pd.Series(dtype="float64"),
            unrealized_pnl_pct=pd.Series(dtype="float64"),
        )

    conn, should_close = _connect(db)

    try:
        latest_prices = pd.read_sql_query(
            """
            SELECT c.ticker, c.date AS latest_date, c.close AS latest_close
            FROM candles_daily c
            JOIN (
                SELECT ticker, MAX(date) AS latest_date
                FROM candles_daily
                GROUP BY ticker
            ) latest
                ON c.ticker = latest.ticker
                AND c.date = latest.latest_date;
            """,
            conn,
        )
    finally:
        if should_close:
            conn.close()

    marked = current_positions.merge(latest_prices, on="ticker", how="left")
    marked["market_value"] = marked["qty"] * marked["latest_close"]
    marked["unrealized_pnl"] = marked["market_value"] - marked["cost_basis"]
    marked["unrealized_pnl_pct"] = marked["unrealized_pnl"] / marked["cost_basis"]
    return marked
