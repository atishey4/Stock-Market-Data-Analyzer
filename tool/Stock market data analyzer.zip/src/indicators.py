from pathlib import Path
import sqlite3

import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import MACD, SMAIndicator
from ta.volatility import BollingerBands


INDICATOR_COLUMNS = [
    "ticker",
    "date",
    "sma20",
    "sma50",
    "rsi14",
    "macd",
    "macd_signal",
    "macd_hist",
    "bb_upper",
    "bb_mid",
    "bb_lower",
]


def _connect(db: str | Path | sqlite3.Connection) -> tuple[sqlite3.Connection, bool]:
    if isinstance(db, sqlite3.Connection):
        return db, False

    return sqlite3.connect(db), True


def _read_candles(conn: sqlite3.Connection, ticker: str) -> pd.DataFrame:
    return pd.read_sql_query(
        """
        SELECT ticker, date, open, high, low, close, adj_close, volume
        FROM candles_daily
        WHERE ticker = ?
        ORDER BY date;
        """,
        conn,
        params=(ticker,),
    )


def _value(row: pd.Series | dict, column: str):
    if isinstance(row, pd.Series):
        return row.get(column)

    return row.get(column)


def calculate_indicators(candles: pd.DataFrame) -> pd.DataFrame:
    indicators = candles.copy()
    close = indicators["close"]

    indicators["sma20"] = SMAIndicator(close=close, window=20).sma_indicator()
    indicators["sma50"] = SMAIndicator(close=close, window=50).sma_indicator()
    indicators["rsi14"] = RSIIndicator(close=close, window=14).rsi()

    macd = MACD(close=close)
    indicators["macd"] = macd.macd()
    indicators["macd_signal"] = macd.macd_signal()
    indicators["macd_hist"] = macd.macd_diff()

    bollinger = BollingerBands(close=close)
    indicators["bb_upper"] = bollinger.bollinger_hband()
    indicators["bb_mid"] = bollinger.bollinger_mavg()
    indicators["bb_lower"] = bollinger.bollinger_lband()

    return indicators[INDICATOR_COLUMNS]


def simple_signal(prev_row: pd.Series | dict, curr_row: pd.Series | dict) -> str:
    prev_sma20 = _value(prev_row, "sma20")
    prev_sma50 = _value(prev_row, "sma50")
    curr_sma20 = _value(curr_row, "sma20")
    curr_sma50 = _value(curr_row, "sma50")

    if pd.isna(prev_sma20) or pd.isna(prev_sma50) or pd.isna(curr_sma20) or pd.isna(curr_sma50):
        return "HOLD"

    if prev_sma20 <= prev_sma50 and curr_sma20 > curr_sma50:
        return "BUY"

    if prev_sma20 >= prev_sma50 and curr_sma20 < curr_sma50:
        return "SELL"

    return "HOLD"


def compute_indicators(db: str | Path | sqlite3.Connection, ticker: str) -> int:
    conn, should_close = _connect(db)

    try:
        candles = _read_candles(conn, ticker)
        if candles.empty:
            return 0

        indicators = calculate_indicators(candles)
        rows = [
            tuple(None if pd.isna(value) else value for value in row)
            for row in indicators.itertuples(index=False, name=None)
        ]

        conn.executemany(
            """
            INSERT OR REPLACE INTO indicators_daily (
                ticker, date, sma20, sma50, rsi14, macd, macd_signal, macd_hist,
                bb_upper, bb_mid, bb_lower
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """,
            rows,
        )
        conn.commit()
    finally:
        if should_close:
            conn.close()

    return len(rows)
