from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


OUTPUTS_DIR = Path(__file__).resolve().parents[1] / "outputs"


def _prepare(df: pd.DataFrame) -> pd.DataFrame:
    frame = df.copy()
    if "date" in frame.columns:
        frame["date"] = pd.to_datetime(frame["date"])
        frame = frame.sort_values("date")

    return frame


def _save(fig: plt.Figure, filename: str) -> Path:
    OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
    path = OUTPUTS_DIR / filename
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def price_with_ma(df: pd.DataFrame, ticker: str) -> Path:
    frame = _prepare(df)
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(frame["date"], frame["close"], label="Close", linewidth=1.6)
    ax.plot(frame["date"], frame["sma20"], label="SMA20", linewidth=1.2)
    ax.plot(frame["date"], frame["sma50"], label="SMA50", linewidth=1.2)
    ax.set_title(f"{ticker} Price with Moving Averages")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price")
    ax.legend()
    ax.grid(True, alpha=0.25)
    return _save(fig, f"{ticker}_price_with_ma.png")


def daily_returns(df: pd.DataFrame, ticker: str) -> Path:
    frame = _prepare(df)
    returns = frame["close"].pct_change().dropna()
    mean = returns.mean()
    std = returns.std()

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.hist(returns, bins=40, density=True, alpha=0.65, label="Daily returns")

    if std and not np.isnan(std):
        x = np.linspace(returns.min(), returns.max(), 200)
        y = (1 / (std * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mean) / std) ** 2)
        ax.plot(x, y, linewidth=2, label="Normal curve")

    ax.set_title(f"{ticker} Daily Returns")
    ax.set_xlabel("Return")
    ax.set_ylabel("Density")
    ax.legend()
    ax.grid(True, alpha=0.25)
    return _save(fig, f"{ticker}_daily_returns.png")


def volatility_rolling(df: pd.DataFrame, ticker: str) -> Path:
    frame = _prepare(df)
    rolling_volatility = frame["close"].pct_change().rolling(30).std() * np.sqrt(252)

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(frame["date"], rolling_volatility, label="30D annualized volatility")
    ax.set_title(f"{ticker} Rolling Volatility")
    ax.set_xlabel("Date")
    ax.set_ylabel("Volatility")
    ax.legend()
    ax.grid(True, alpha=0.25)
    return _save(fig, f"{ticker}_rolling_volatility.png")


def bollinger_chart(df: pd.DataFrame, ticker: str) -> Path:
    frame = _prepare(df)
    fig, ax = plt.subplots(figsize=(12, 6))
    ax.plot(frame["date"], frame["close"], label="Close", linewidth=1.5)
    ax.plot(frame["date"], frame["bb_upper"], label="BB Upper", linewidth=1)
    ax.plot(frame["date"], frame["bb_mid"], label="BB Mid", linewidth=1)
    ax.plot(frame["date"], frame["bb_lower"], label="BB Lower", linewidth=1)
    ax.fill_between(
        frame["date"],
        frame["bb_lower"],
        frame["bb_upper"],
        alpha=0.15,
        label="Bollinger Band",
    )
    ax.set_title(f"{ticker} Bollinger Bands")
    ax.set_xlabel("Date")
    ax.set_ylabel("Price")
    ax.legend()
    ax.grid(True, alpha=0.25)
    return _save(fig, f"{ticker}_bollinger_bands.png")
