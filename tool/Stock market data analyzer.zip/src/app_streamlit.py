from datetime import date, timedelta
from pathlib import Path
import sqlite3
import sys

import pandas as pd
import plotly.graph_objects as go
import streamlit as st


BASE_DIR = Path(__file__).resolve().parents[1]
DB_PATH = BASE_DIR / "db" / "stock_market.db"
TRADING_DAYS = 252
DEFAULT_TICKERS = ["RELIANCE.NS", "TCS.NS", "INFY.NS", "^NSEI"]
TICKER_LABELS = {
    "RELIANCE.NS": "Reliance Industries (RELIANCE.NS)",
    "TCS.NS": "Tata Consultancy Services (TCS.NS)",
    "INFY.NS": "Infosys (INFY.NS)",
    "^NSEI": "Nifty 50 Index (^NSEI)",
}

if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.backtest import run_sma_backtest


st.set_page_config(page_title="Stock Market Data Analyzer", layout="wide")


@st.cache_data(ttl=60)
def available_tickers() -> list[str]:
    if not DB_PATH.exists():
        return DEFAULT_TICKERS

    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            """
            SELECT DISTINCT ticker
            FROM candles_daily
            ORDER BY ticker;
            """
        ).fetchall()

    tickers = [row[0] for row in rows]
    return list(dict.fromkeys(DEFAULT_TICKERS + tickers))


@st.cache_data(ttl=60)
def load_chart_data(ticker: str, start: date, end: date) -> pd.DataFrame:
    query = """
        SELECT
            c.ticker,
            c.date,
            c.open,
            c.high,
            c.low,
            c.close,
            c.adj_close,
            c.volume,
            i.sma20,
            i.sma50,
            i.rsi14,
            i.macd,
            i.macd_signal,
            i.macd_hist,
            i.bb_upper,
            i.bb_mid,
            i.bb_lower
        FROM candles_daily c
        LEFT JOIN indicators_daily i
            ON c.ticker = i.ticker
            AND c.date = i.date
        WHERE c.ticker = ?
            AND c.date >= ?
            AND c.date <= ?
        ORDER BY c.date;
    """
    with sqlite3.connect(DB_PATH) as conn:
        frame = pd.read_sql_query(
            query,
            conn,
            params=(ticker, start.isoformat(), end.isoformat()),
            parse_dates=["date"],
        )

    return frame


def format_pct(value: float | None) -> str:
    if value is None or pd.isna(value):
        return "-"

    return f"{value:.2%}"


def format_number(value: float | None) -> str:
    if value is None or pd.isna(value):
        return "-"

    return f"{value:,.2f}"


def kpis(frame: pd.DataFrame) -> dict:
    if frame.empty:
        return {
            "current_price": None,
            "daily_return": None,
            "high_52w": None,
            "low_52w": None,
            "volatility": None,
        }

    close = frame["close"]
    returns = close.pct_change().dropna()
    current_price = close.iloc[-1]
    previous_price = close.iloc[-2] if len(close) > 1 else None
    daily_return = (
        current_price / previous_price - 1
        if previous_price is not None and previous_price != 0
        else None
    )

    return {
        "current_price": current_price,
        "daily_return": daily_return,
        "high_52w": frame.tail(TRADING_DAYS)["high"].max(),
        "low_52w": frame.tail(TRADING_DAYS)["low"].min(),
        "volatility": returns.std() * (TRADING_DAYS**0.5) if not returns.empty else None,
    }


def price_chart(frame: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(
        go.Candlestick(
            x=frame["date"],
            open=frame["open"],
            high=frame["high"],
            low=frame["low"],
            close=frame["close"],
            name="OHLC",
        )
    )
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["sma20"], mode="lines", name="SMA20")
    )
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["sma50"], mode="lines", name="SMA50")
    )
    fig.update_layout(
        height=520,
        margin=dict(l=10, r=10, t=35, b=10),
        xaxis_rangeslider_visible=False,
        legend_orientation="h",
        title="Price",
    )
    return fig


def rsi_chart(frame: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["rsi14"], mode="lines", name="RSI14")
    )
    fig.add_hline(y=70, line_dash="dash", line_color="red")
    fig.add_hline(y=30, line_dash="dash", line_color="green")
    fig.update_layout(
        height=300,
        margin=dict(l=10, r=10, t=35, b=10),
        yaxis_range=[0, 100],
        title="RSI",
    )
    return fig


def macd_chart(frame: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(
        go.Bar(x=frame["date"], y=frame["macd_hist"], name="Histogram")
    )
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["macd"], mode="lines", name="MACD")
    )
    fig.add_trace(
        go.Scatter(
            x=frame["date"],
            y=frame["macd_signal"],
            mode="lines",
            name="Signal",
        )
    )
    fig.update_layout(
        height=320,
        margin=dict(l=10, r=10, t=35, b=10),
        legend_orientation="h",
        title="MACD",
    )
    return fig


def bollinger_chart(frame: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["close"], mode="lines", name="Close")
    )
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["bb_upper"], mode="lines", name="Upper")
    )
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["bb_mid"], mode="lines", name="Middle")
    )
    fig.add_trace(
        go.Scatter(x=frame["date"], y=frame["bb_lower"], mode="lines", name="Lower")
    )
    fig.update_layout(
        height=320,
        margin=dict(l=10, r=10, t=35, b=10),
        legend_orientation="h",
        title="Bollinger Bands",
    )
    return fig


def equity_chart(equity_curve: list[dict]) -> go.Figure:
    curve = pd.DataFrame(equity_curve)
    fig = go.Figure()
    if not curve.empty:
        fig.add_trace(
            go.Scatter(
                x=pd.to_datetime(curve["date"]),
                y=curve["equity"],
                mode="lines",
                name="Equity",
            )
        )
    fig.update_layout(
        height=360,
        margin=dict(l=10, r=10, t=35, b=10),
        title="Equity Curve",
    )
    return fig


def ticker_label(ticker: str) -> str:
    return TICKER_LABELS.get(ticker, ticker)


st.title("Stock Market Data Analyzer")

with st.sidebar:
    ticker_options = available_tickers()
    ticker = st.selectbox(
        "Ticker",
        options=ticker_options,
        index=0,
        format_func=ticker_label,
    )
    default_end = date.today()
    default_start = default_end - timedelta(days=365)
    selected_range = st.date_input(
        "Date range",
        value=(default_start, default_end),
        max_value=default_end,
    )
    fee_bps = st.number_input("Backtest fee, bps", min_value=0.0, value=5.0, step=1.0)
    st.caption(
        "Fee is measured in basis points. 5 bps means 0.05% transaction cost "
        "charged whenever the strategy enters or exits a position."
    )

if isinstance(selected_range, tuple) and len(selected_range) == 2:
    start_date, end_date = selected_range
else:
    start_date = default_start
    end_date = default_end

data = load_chart_data(ticker, start_date, end_date)

if data.empty:
    st.info(
        "No local candle data found for this ticker and date range. Run "
        "`python main.py` from the project folder to download and compute data."
    )
    st.stop()

metrics = kpis(data)
cols = st.columns(5)
cols[0].metric("Current Price", format_number(metrics["current_price"]))
cols[1].metric("52W High", format_number(metrics["high_52w"]))
cols[2].metric("52W Low", format_number(metrics["low_52w"]))
cols[3].metric("Daily Return", format_pct(metrics["daily_return"]))
cols[4].metric("Volatility", format_pct(metrics["volatility"]))

st.plotly_chart(price_chart(data), use_container_width=True)

left, right = st.columns(2)
with left:
    st.plotly_chart(rsi_chart(data), use_container_width=True)
    st.plotly_chart(bollinger_chart(data), use_container_width=True)

with right:
    st.plotly_chart(macd_chart(data), use_container_width=True)

st.subheader("Backtest Results")
st.markdown(
    """
    This backtest uses a simple SMA crossover strategy. It is **long-only**:
    it holds the ticker when SMA20 is above SMA50 and stays in cash otherwise.
    Signals are applied on the next trading day to reduce lookahead bias.
    Transaction fees are subtracted whenever the position changes.
    """
)
if st.button("Run SMA Backtest", type="primary"):
    result = run_sma_backtest(
        DB_PATH,
        ticker,
        fee_bps=fee_bps,
        start=start_date.isoformat(),
        end=end_date.isoformat(),
    )

    result_cols = st.columns(4)
    result_cols[0].metric("PnL", format_pct(result["pnl"]))
    result_cols[1].metric("Sharpe", format_number(result["sharpe"]))
    result_cols[2].metric("Max Drawdown", format_pct(result["max_dd"]))
    result_cols[3].metric("Trades", result["trades"])
    st.plotly_chart(equity_chart(result["equity_curve"]), use_container_width=True)
